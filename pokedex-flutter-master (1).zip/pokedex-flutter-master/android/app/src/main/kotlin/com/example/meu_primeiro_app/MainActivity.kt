package com.example.meu_primeiro_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
